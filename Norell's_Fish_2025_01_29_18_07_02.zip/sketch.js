function setup() {
  angleMode(DEGREES)
  createCanvas(400, 400);
}

function draw() {
  background("cornflowerblue");

noStroke();  
fill("khaki");
rect(0,340,400,70);
  
strokeWeight(3);  
stroke("darkorange");
  
fill("orange");
triangle(220, 245, 240, 230, 240, 260);  
ellipse(150, 250, 150, 60);
  
triangle(160,250,160,270,170,260);
  
fill('black');
stroke("white");  
ellipse(110,250,20,15);

fill('white');
noStroke();  
ellipse(105,245,5);

fill("lightsalmon")
stroke("salmon")  
ellipse(250,115,160,50)  
triangle(170,115,140,140,140,90)

fill('black');
stroke("white");  
strokeWeight(2);
ellipse(300,113,15,10);
  
fill('white');
noStroke();  
ellipse(303,110,5);

ellipse(45,190,10);   
ellipse(60,210,15);
ellipse(50,240,10);
}